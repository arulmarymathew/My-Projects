package com.niit.ShoppingCart.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RegistrationController {
	
	@RequestMapping("index")
	public String home()
	{
		return "redirect:/onLoad";
	}

}
