package com.niit.ShoppingCart.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;




@Controller
public class UserController {
	
	@Autowired
	private UserDAO userDAO; 
	
	@Autowired
	private User user;
//	
	@Autowired
	private CategoryDAO categoryDAO;

	@Autowired
	private Category category;
	
//	@Autowired
//	private Cart cart;
//	
//	@Autowired
//	private CartDAO cartDAO;
//	@Autowired
//	private UserDetails user;


	@RequestMapping("/")
	public String getLanding(HttpSession session) {
		System.out.println("Landing  page is loaded");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		
		return "index";
	}

	@RequestMapping("/Home")
	public String getHome() {
		System.out.println("home page is loaded");
		return "Home";
	}

	@RequestMapping("/About")
	public String getAbout() {
		System.out.println("about page is loaded");
		return "About";
	}

	@RequestMapping("/Contactus")
	public String getContactus() {
		System.out.println("contact us page is loaded");
		return "Contactus";
	}
	
	
	@RequestMapping("/Signup")
	public ModelAndView signup(){
		ModelAndView mv = new ModelAndView("/index");
		mv.addObject("user", user);
		mv.addObject("isUserClickRegisterHere", "true");
		return mv;
	}
	
	@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User user){
		userDAO.saveOrUpdate(user);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
	
	
	/*public String getsignup()
	{
		System.out.println("sign-up page is loaded");
		return "Signup";
	}*/

	@RequestMapping("/Login")
	public String getLogin()
	{
		System.out.println("Login page is loaded");
		return "Login";
	}

	@RequestMapping("/check")
	public ModelAndView login (@RequestParam (name="name")String name, @RequestParam (name="password") String password)
	{
		ModelAndView mv;
		boolean isValidUser = userDAO.isValidUser(name,password);
		if(isValidUser)
		{
			mv= new ModelAndView("/Admin");
			mv.addObject("message","valid user");
//			user=userDAO.get(name);
//			if(user.getAdmin()==1)
//			{
//				mv.addObject("message","valid user"+user.getName());
//			}
			
		}
		else
		{
			mv= new ModelAndView("/Fail");
			mv.addObject("message","invalid user");
		}
		
		return mv;
	}
}
	
	
	
	/*	@RequestMapping(value="/loginUser")
		public String login(@RequestParam (value="error", required = false) String error,
				            @RequestParam(value="logout", required = false) String logout, Model model)
{
			if(error != null)
			{
				System.out.println("Error...");
				model.addAttribute("error", "Invalid username and password");
			}
			
			if(logout != null)
			{
				System.out.println("Logout called...");
				model.addAttribute("msg", "You have been logged out successfully..");
			}
			return "loginUser";
}*/
		
		
//		@RequestMapping(value = "/user")
//		public String userManagement ()
//		{
//			System.out.println("User Called...!");
//			return "loginuser";
//		}
//		
//		@RequestMapping(value = "/admin")
//		public String adminManagement ()
//		{
//			System.out.println("Admin Called..!");
//			return "admin";
//		}
//		
//		@RequestMapping(value="/afterLogin", method = RequestMethod.GET)
//		public String afterLogint()
//		{
//			return "afterLoginUser";
//		}
//		
//}
//
