package com.niit.ShoppingCart.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.UserDetails;

@Controller
public class UserController {
	
	@Autowired
	private UserDAO userDAO; 
	
	@Autowired
	private UserDetails userDetails;


	@RequestMapping("/")
	public String getLanding() {
		System.out.println("Landing  page is loaded");
		return "index";
	}

	@RequestMapping("/Home")
	public String getHome() {
		System.out.println("home page is loaded");
		return "Home";
	}

	@RequestMapping("/About")
	public String getAbout() {
		System.out.println("about page is loaded");
		return "About";
	}

	@RequestMapping("/Contactus")
	public String getContactus() {
		System.out.println("contact us page is loaded");
		return "Contactus";
	}

	@RequestMapping("/Login")
	public String getLogin()
	{
		System.out.println("Login page is loaded");
		return "Login";
	}

	@RequestMapping("/check")
	public ModelAndView login (@RequestParam (name="name")String name, @RequestParam (name="password") String password)
	{
		ModelAndView mv;
		boolean isValidUser = userDAO.isValidUser(name,password);
		if(isValidUser)
		{
			mv= new ModelAndView("/Admin");
			mv.addObject("message","valid user");
//			userDetails=userDAO.get(name);
//			if(userDetails.getAdmin()==1)
//			{
//				mv.addObject("message","valid user"+userDetails.getName());
//			}
			
		}
		else
		{
			mv= new ModelAndView("/Fail");
			mv.addObject("message","invalid user");
		}
		
		return mv;
	}
	
	

	@RequestMapping("/signup")
	public String getsign()
	{
		return "signup";
	}
}










	