package com.niit.ShoppingCart.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.type.TrueFalseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;




@Controller
public class UserController {
	
	@Autowired
	private UserDAO userDAO; 
	
	@Autowired
	private User user;
//	
	@Autowired
	private CategoryDAO categoryDAO;

	@Autowired
	private Category category;
	
//	@Autowired
//	private Cart cart;
//	
//	@Autowired
//	private CartDAO cartDAO;
//	@Autowired
//	private UserDetails user;


	@RequestMapping("/")
	public ModelAndView getLanding(HttpSession session) {
		
		ModelAndView mv = new ModelAndView("/index");
		//System.out.println("Landing  page is loaded");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		return mv;
		//return "index";
	}

	@RequestMapping("/Home")
	public String getHome() {
		System.out.println("home page is loaded");
		return "Home";
	}

	@RequestMapping("/About")
	public String getAbout() {
		System.out.println("about page is loaded");
		return "About";
	}

	@RequestMapping("/Contactus")
	public String getContactus() {
		System.out.println("contact us page is loaded");
		return "Contactus";
	}
	
	
	@RequestMapping("/Signup")
	public ModelAndView signup(){
		ModelAndView mv = new ModelAndView("/index");
		mv.addObject("user", user);
		mv.addObject("isUserClickRegisterHere", "true");
		return mv;
	}
	
	@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User user){
		userDAO.saveOrUpdate(user);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}
	
	
	/*public String getsignup()
	{
		System.out.println("sign-up page is loaded");
		return "Signup";
	}*/

	@RequestMapping("/Login")
	public String getLogin()
	{
		System.out.println("Login page is loaded");
		return "Login";
	}

/*	@RequestMapping("/check")
	public ModelAndView login (@RequestParam (name="name")String name, @RequestParam (name="password") String password ,HttpSession session)
	{
		ModelAndView mv;
		boolean isValidUser = userDAO.isValidUser(name,password);
		if(isValidUser)
		{
			mv= new ModelAndView("/Admin");
			mv.addObject("message","valid user");
//			user=userDAO.get(name);
//			if(user.getAdmin()==1)
//			{
//				mv.addObject("message","valid user"+user.getName());
//			}
			
		}
		else
		{
			mv= new ModelAndView("/Fail");
			mv.addObject("message","invalid user");
		}
		
		return mv;
	}

	
	*/
	/*
		@RequestMapping(value="/login",method=RequestMethod.GET)
		public ModelAndView login(@RequestParam (value="error", required = true) String error,
				            @RequestParam(value="logout", required = false) String logout)
{
			ModelAndView model=new ModelAndView();
			if(error != null)
			{
				System.out.println("Error...");
				model.addObject("error", "Invalid username and password");
			}
			
			if(logout != null)
			{
				System.out.println("Logout called...");
				model.addObject("msg", "You have been logged out successfully..");
			}
			model.setViewName("login");
			return model;
}*/
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpSession session)
	{
		ModelAndView mv=new ModelAndView("/index");
		session.invalidate();
		session = request.getSession(true);
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		
		mv.addObject("logoutMessage", "You successfully logged out");
		mv.addObject("loggedOut", "true");
		return mv;
	}
}
		
//		@RequestMapping(value = "/user")
//		public String userManagement ()
//		{
//			System.out.println("User Called...!");
//			return "loginuser";
//		}
//		
//		@RequestMapping(value = "/admin")
//		public String adminManagement ()
//		{
//			System.out.println("Admin Called..!");
//			return "admin";
//		}
//		
//		@RequestMapping(value="/afterLogin", method = RequestMethod.GET)
//		public String afterLogint()
//		{
//			return "afterLoginUser";
//		}
//		
//}
//
