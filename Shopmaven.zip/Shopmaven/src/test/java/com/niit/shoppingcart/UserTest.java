package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcart");
		context.refresh();
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");

		User user = (User) context.getBean("user");
		user.setId("A120");
		user.setName("Arvind");
		user.setPassword("job");
		user.setMobile("9987816525");
		user.setMail("ar@gmail");
		user.setAddress("Mumbai");
		user.setAdmin((byte) 1);
		
		
		
		//userDAO.saveOrUpdate(user);
		if(userDAO.get("A412")==null)
		{
			System.out.println("product doesnt exit");
		}
		else
		{
			System.out.println("product exist....");
			System.out.println();
		}
	}
}
