package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.shoppingcart");
		context.refresh();
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");

		Product product = (Product) context.getBean("product");
		product.setId("A142");
		product.setName("mary");
		product.setDescription("jobs");
		
		//productDAO.saveOrUpdate(product);
     	if(productDAO.get("A142")==null)
		{
			System.out.println("product doesnt exit");
		}
		else
		{
			System.out.println("product exist....");
			System.out.println();
		}
		//productDAO.delete("A142");
	}
}
