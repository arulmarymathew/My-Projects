package com.niit.shoppingcart.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.UserDetails;

public class TestUserDAO {
	
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	UserDetails userDetails;

	AnnotationConfigApplicationContext context;
	
	@Before
	public void init()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("niit.com");
		context.refresh();
		
		userDAO = (UserDAO) context.getBean("userDAO"); 
		userDetails = (UserDetails) context.getBean("userDetails");
	}
	
	public void UsersTestCase()
	{
		int size = userDAO.list().size();
		assertEquals("User List Test Case",5,size);
	}
	}





















